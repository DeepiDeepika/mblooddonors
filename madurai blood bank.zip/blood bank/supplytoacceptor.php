
<?php
include "./adminpage.php";
?>
<br><br>
<br>
<br>
<br>
<br>

   <section >

        
        <div align='center'>
<?php
include("db.php");
if(!isset($_POST['submit']) && !isset($_POST['submit1'])) {
	$rs = mysql_query("select id from acceptorreq where requnit-issunit>0") or die(mysql_error());
?>
<form name="f" action="" method="post">

<table align="center">
<center>
<tr>
<th><h1>Select Request Id</h1>
<td>
<select name="rid" required>
<?php
	while($r = mysql_fetch_row($rs)) {
	echo "<option value=$r[0]>$r[0]</option>";
	}	
?>
</select>
<tr>
<th colspan="2"><input type="submit" name="submit" value="Fetch" class="btn-login">
</center>
</table>
</form>
<?php
} else if(isset($_POST['submit']) && !isset($_POST['submit1'])) {
	$rid = $_POST['rid'];
	$rs = mysql_query("select name,bgroup,requnit-issunit,id from acceptorreq r,acceptor a where r.userid=a.userid and id=$rid");
	$row = mysql_fetch_row($rs);
	echo "<table align='center' border='1'><tr><th>Name<th>Bloodgroup<th>Unit Requested";
	echo "<tr><td>$row[0]<td>$row[1]<td>$row[2]</table><br>";
        
	$rs1 = mysql_query("select tranid,donorname,units from bloodstore where bloodgroup='$row[1]' and issued='no'") or die(mysql_error());
	if(mysql_num_rows($rs1)>0) {
	echo "<form name='f' action='' method='post'><table align='center' border='1'><tr><th colspan='4'>Blood Availability<tr><th>Select<th>Id<th>Name<th>Units";
	echo "<input type='hidden' name='hrequnit' value='$row[2]'>";
	echo "<input type='hidden' name='hid' value='$row[3]'>";
	while($row1 = mysql_fetch_row($rs1)) {
		echo "<tr><td><input type='checkbox' name='cid[]' value='$row1[0]'><td>$row1[0]<td>$row1[1]<td>$row1[2]";
	}
	echo "<tr><th colspan='4'><input type='submit' name='submit1' value='ISSUE'>";
	echo "</table></form>";
	} else {
		echo "<p style='text-align:center'><h2>Sorry! No Stock available in this Blood Group</h2></p>";
	}
} else if(isset($_POST['submit1'])) {
	if(isset($_POST['cid'])) {
		$requnit = $_POST['hrequnit'];
		$tranid = $_POST['cid'];
		$count = count($tranid);
		$aid = $_POST['hid'];

		if($count<=$requnit) {
			foreach($tranid as $t) {
			mysql_query("update bloodstore set issued='yes' where tranid=$t") or die(mysql_error());
			}
		mysql_query("update acceptorreq set issunit=issunit+$count where id=$aid") or die(mysql_error());
		} else if($count>$requnit) {
			for($i=0; $i<$requnit; $i++) {
			mysql_query("update bloodstore set issued='yes' where tranid=$tranid[$i]") or die(mysql_error());
			}
		mysql_query("update acceptorreq set issunit=issunit+$requnit where id=$aid") or die(mysql_error());
		}
	echo "<p style='text-align:center;'>Blood Issued...!<br><a href='supplytoacceptor.php'><center>Back</center></a></p>";
	} else {
		echo "<p style='text-align:center;'>Select Checkbox before submit...!</p>";
	}
}
?>
</div>
</section>
</body>
<style>
.btn-login{
	padding: 10px 20px;
	border: none;
	background-color: black;
	color: white;
        border-radius: 20px;
}
table{
 position: absolute;
 z-index: 2;
 left: 50%;
 top: 50%;
 transform: translate(-50%,-50%);
 width: 30%; 
 border-collapse: collapse;
 border-spacing: 0;
 box-shadow: 0 2px 10px rgba(64,64,64,.7);
 border-radius: 12px 12px 0 0;
 overflow: hidden;

}
td , th{
 padding: 15px 20px;
 text-align: center;
 

}
th{
 background-color: #ba68c8;
 color: #fafafa;
 font-family: 'Open Sans',Sans-serif;
 font-weight: 200;
 text-transform: uppercase;

}
tr{
 width: 100%;
 background-color: #fafafa;
 font-family: 'Montserrat', sans-serif;
}
tr:nth-child(even){
 background-color: #eeeeee;
}

</style>
</html>