<html>
<head>
<style>
.alnr{text-align:right;}
.clr{background-color:black;}
h3{color:white;}
background-image: url("lab2.jpg");
</style>
<script type="text/javascript">
function check() {
name=f.t1.value
age=f.t2.value
fname=f.t3.value
addr=f.t4.value
mob=f.t6.value
college=f.t7.value
height=f.t8.value
weight=f.t9.value
ph=f.photo.value
cert=f.certificate.value
if(name==""||age==""||fname==""||addr==""||mob==""||college==""||height==""||weight==""||ph==""||cert=="") {
alert("Field should not be Empty")
return false
}
if(!f.g[0].checked && !f.g[1].checked) {
alert("Select the Gender")
return false
}
if(!f.m[0].checked && !f.m[1].checked) {
alert("Select the Marital Status")
return false
}
if(!f.e[0].checked && !f.e[1].checked && !f.e[2].checked && !f.e[3].checked) {
alert("Select the Educational Status")
return false
}
if(!f.p[0].checked && !f.p[1].checked) {
alert("Select Physically challenged Y/N")
return false
}
if(!f.i[0].checked && !f.i[1].checked && !f.i[2].checked) {
alert("Select Illness Category")
return false
}
if(!f.c1.checked && !f.c2.checked && !f.c3.checked && !f.c4.checked) {
alert("Select Behavioural Activties")
return false
}
return true
}
</script>
</head>
<body bgcolor="#bb0000">
<?php
if(!isset($_POST['submit'])) {
?>
<form name="f" action="newuser.php" method="post" onsubmit="return check()" enctype="multipart/form-data">
<table align="center" border="0" style="background-color:gray;">
<tr class="clr">
<td colspan="2" align="center" style="vertical-align:bottom;height:50;"><h3>Personal Information</h3></td>
</tr>
<tr>
<td class="alnr">Enter Your Full Name</td>
<td><input type="text" name="t1"></td>
</tr>
<tr>
<td class="alnr">Select Your Gender</td>
<td><input type="radio" name="g" value="male">Male <input type="radio" name="g" value="female">Female</td>
</tr>
<tr>
<td class="alnr">Enter Your Age</td>
<td><input type="text" name="t2"></td>
</tr>
<tr>
<td class="alnr">Marital Status</td>
<td><input type="radio" name="m" value="yes">Yes <input type="radio" name="m" value="no">No</td>
</tr>
<tr>
<td class="alnr">Father's Name</td>
<td><input type="text" name="t3"></td>
</tr>
<tr>
<td class="alnr">Address for Communication</td>
<td><textarea name="t4"></textarea></td>
</tr>
<tr>
<td class="alnr">City</td>
<td>
<select name="t5">
<option value="Chennai">Chennai
<option value="Dindivanam">Dindivanam
<option value="Velur">Velur
<option value="Thanjavur">Thanjavur
<option value="Trichy">Trichy
<option value="Coimbatore">Coimbatore
<option value="Dindigul">Dindigul
<option value="Madurai">Madurai
<option value="Tuticorin">Tuticorin
</select>
</td>
</tr>
<tr>
<td class="alnr">Mobile Phone</td>
<td><input type="text" name="t6"></td>
</tr>
<tr class="clr">
<td colspan="2" align="center" style="vertical-align:bottom;height:50;"><h3>Educational Qualification</h3></td>
</tr>
<tr>
<td class="alnr">Educational Status</td>
<td><input type="radio" name="e" value="p2">+2 <input type="radio" name="e" value="ug">U.G. <input type="radio" name="e" value="pg">P.G. <input type="radio" name="e" value="others">Others</td>
</tr>
<tr>
<td class="alnr">College of Study</td>
<td><input type="text" name="t7"></td>
</tr>
<tr class="clr">
<td colspan="2" align="center" style="vertical-align:bottom;height:50;"><h3>Physical Status</h3></td>
</tr>
<tr>
<td class="alnr">Are You Physically Challenged</td>
<td><input type="radio" name="p" value="yes">Yes <input type="radio" name="p" value="no">No</td>
</tr>
<tr>
<td class="alnr">Your Height (in Cm)</td>
<td><input type="text" name="t8"></td>
</tr>
<tr>
<td class="alnr">Your Weight (in Kgs)</td>
<td><input type="text" name="t9"></td>
</tr>
<tr class="clr">
<td colspan="2" align="center" style="vertical-align:bottom;height:50;"><h3>Behavioural Activities</h3></td>
</tr>
<tr>
<td class="alnr">Drug Usage</td>
<td><input type="checkbox" id="c1" name="c[]" value="smoke">Smoking <input type="checkbox" id="c2" name="c[]" value="liquor">Liquors <input type="checkbox" id="c3" name="c[]" value="drug">Drugs <input type="checkbox" name="c[]" id="c4" value="none">None</td>
</tr>
<tr class="clr">
<td colspan="2" align="center" style="vertical-align:bottom;height:50;"><h3>Medicinal Information</h3></td>
</tr>
<tr>
<td class="alnr">Blood Group</td>
<td>
<select name="t10">
<option value="o+">O+
<option value="o-">O-
<option value="a1+">A+
<option value="a1-">A-
<option value="b+">B+
<option value="b-">B-
<option value="ab+">AB+
<option value="ab-">AB-
</select>
</td>
</tr>
<tr>
<td class="alnr">Affected by Illness</td>
<td><input type="radio" name="i" value="six">Within Last 6 Months <input type="radio" name="i" value="one">Within Last 1 Year <input type="radio" name="i" value="none">Before 1 Year</td>
</tr>
<tr class="clr">
<td colspan="2" align="center" style="vertical-align:bottom;height:50;"><h3>Id Proofs</h3></td>
</tr>
<tr>
<td class="alnr">Your Recent Photograph</td>
<td><input type="file" name="photo"></td>
</tr>
<tr>
<td class="alnr">Your Regional Medical Authority Certificate Copy</td>
<td><input type="file" name="certificate"></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="REGISTER">&nbsp;<input type="reset" value="CLEAR">&nbsp;<a href="dlogin.php">Back to Loginpage</a></td>
</tr>
</table>
</form>
<?php
} else if(isset($_POST['submit'])) {
include("db.php");
	$name=$_POST['t1'];
	$gender=$_POST['g'];
	$age=$_POST['t2'];
	$marital = $_POST['m'];
	$father=$_POST['t3'];
	$addr=$_POST['t4'];
	$city=$_POST['t5'];
	$mob=$_POST['t6'];
	$edu=$_POST['e'];
	$college=$_POST['t7'];
	$phys=$_POST['p'];
	$height=$_POST['t8'];
	$weight=$_POST['t9'];
	$drug=$_POST['c']; $dd="";
	foreach($drug as $d)
	$dd .=$d.",";
	$blood=$_POST['t10'];
	$ill=$_POST['i'];
	
	if($_FILES['photo']['size']>0 && $_FILES['photo']['error']==0) {
	$target1 = "./pics/".basename($_FILES['photo']['name']);
	move_uploaded_file($_FILES['photo']['tmp_name'],$target1);
	}
	if($_FILES['certificate']['size']>0 && $_FILES['certificate']['error']==0) {
	$target2 = "./proofs/".basename($_FILES['certificate']['name']);
	move_uploaded_file($_FILES['certificate']['tmp_name'],$target2);
	}

	$str = "insert into newuser (name,gender,age,marital,father,addr,city,mobile,edu,college,phys,height,weight,drug,blood,ill,photo,certificate) values('$name','$gender',$age,'$marital','$father','$addr','$city','$mob','$edu','$college','$phys',$height,$weight,'$dd','$blood','$ill','$target1','$target2')";
	mysql_query($str) or die(mysql_error());
	$rs=mysql_query("select max(userid) from newuser") or die(mysql_error());
	$r=mysql_fetch_row($rs);
	echo "<h2 align='center'>Your Id : $r[0]<br>Your <u><i>Name</i></u> is the password<br><a href='newuser.php'>Refresh</a></h2>";
}
?>
</body>
</html>