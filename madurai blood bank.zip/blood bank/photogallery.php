<?php
session_start();
include("db.php");
?>

	<?php
include "./header4.php";
?>
<?php
if(!isset($_POST['submit'])) {
?>
<html>
<head>

   <section >
<link rel="stylesheet" a href="photogallery.css"/>
        
        <div align='center'>
<title>Acceptor Login</title>
</head>
<body>
<div class="container">
        
	<form name="f" action="" method="post">
        <br>
        <h2>Acceptor Login</h2>
        <div class="form-input">
	<input type="text" name="userid" placeholder="Userid">
        </div>
         <div class="form-input">
	 <input type="password" name="pwd" placeholder="Password"/>
	 </div>
	<input type="submit" name="submit" value="Login" class="btn-login"><br>
	<p class="message">Don't have an Id? <a href="newacceptor.php">SignUp</a></p>
	</form>
</div>
<?php
} else {
	$userid = $_POST['userid'];
	$pwd = $_POST['pwd'];
	$result = mysql_query("select * from acceptor where userid='$userid' and pwd='$pwd'") or die(mysql_error());
	if(mysql_num_rows($result)>0) {
		$_SESSION['acceptor']=$userid;
		header("Location:acceptorhome.php");
	} else {
		echo "<br>Invalid Id/Password<Br><a href='photogallery.php'>Back</a>";
	}
}
?>
        </div>       
  
</body></html>