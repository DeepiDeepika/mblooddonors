<?php
session_start();
?>

<?php
include "./header.php";
?>
<br><br>
<br>
<br>
<br>
<br>

   <section>
        
        <div align='center'>
        
<script type="text/javascript">
function call(arg) {
if(arg!="") {
if(window.XMLHttpRequest)
ob=new XMLHttpRequest()
else
ob=new ActiveXObject("Microsoft.XMLHTTP")
ob.onreadystatechange=function() {
if(ob.readyState==4&&ob.status==200) {
document.getElementById("d").innerHTML=ob.responseText
}
}
ob.open("GET","getbanks.php?z="+arg,true)
ob.send()
}
else
document.getElementById("d").innerHTML=""
}
</script>
<?php
include("db.php");
$rs=mysql_query("select distinct area from lists") or die(mysql_error());
echo "<form method='get'>";
echo "Choose the Location ";
echo "<select name='s' onchange='call(this.value)'>";
echo "<option value=''>-- Select --</option>";
while($r=mysql_fetch_array($rs))
echo "<option value='$r[0]'>$r[0]</option>";
echo "</select>";
echo "<div id='d'></div>";
echo "</form>";
?>



        </div>
        
        
        
       </section>
</body></html>