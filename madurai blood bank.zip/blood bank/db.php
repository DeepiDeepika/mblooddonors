<?php
error_reporting(E_ERROR);
$link=mysql_connect("localhost:3306","root","") or die(mysql_error());
mysql_select_db("bloodbank") or die(mysql_error());
?>