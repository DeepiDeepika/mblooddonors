<?php
include "./header2.php";
?>
<html>
    <head>
        <title>NP</title>
        <body>
            <link rel="stylesheet" type="text/css" href="np.css">
        <div class="title">
            <div class="animated slideInUp">
                <div class="well">
            <ul>
            <h1>Who needs blood?</p></h1>
            <p>Normally, every 2 seconds someone needs blood transfusion. Blood transfusion are used for trauma victims due to accidents and burn, heart surgery, organ transplants</p>
            <p>Also women with complication during childbirth, newborns, premature babies. Patients receiving treatment for leukemia, cancer or other diseases. </p>
            <p>One donation of blood can save more than one life when it is separated into red blood cells, plasma, etc. Donating blood is a good way to help people who need it in an emergency.</p>
            <p>Donate blood and saves someone life</p>
        </ul>
        </div>
    </div>
        </div>
    </body>
</head>
</html>