<?php
include("db.php");
	$nm=$_GET['z'];
$rs=mysql_query("select * from lists where area='$nm'") or die(mysql_error());
echo "<table align='center' border='1'>";
echo "<tr><th>Area</th><th>Name</th><th>Phone</th></tr>";
while($r=mysql_fetch_array($rs))
echo "<tr><td>$r[0]</td><td>$r[1]</td><td>$r[2]</td>";
echo "</table>";
?>