<?php
include "./header6.php";
?>
<html>
    <head>
        <title> GALLERY</title>
        <link rel="stylesheet" type="text/css" href="Gallery.css">
        <link rel="stylesheet" type="text/css" href="css/lightbox.min.css">
            <link rel="stylesheet" type="text/css" href="css/style.css">
        <script type="text/javascript" src="js/lightbox-plus-jquery.min.js"></script>
    </head>
    <body background-color: red>
<h1><center>Gallery</center></h1>
        <div class="GALLERY">
<br>
          <a class="one" href="gallery/img4.jpg" data-lightbox="mygallery" data-title="Vaadipatti"> <img src="gallery/pic1.jpg"/></a>
         <a class="two" href="gallery/img3.jpg" data-lightbox="mygallery" data-title="Therkuvasal"> <img src="gallery/pic2.jpg"/></a>
           <a class="three" href="gallery/img2.jpg" data-lightbox="mygallery" data-title="K.Pudur"> <img src="gallery/pic3.jpg"/></a>
           <a class="four" href="gallery/img1.jpg" data-lightbox="mygallery" data-title="Anna Bus Stand"> <img src="gallery/pic4.jpg"/></a>
           <a class="four" href="gallery/img5.jpg" data-lightbox="mygallery" data-title="Anna Bus Stand"> <img src="gallery/pic5.jpg"/></a>
           <a class="four" href="gallery/img6.jpg" data-lightbox="mygallery" data-title="Anna Bus Stand"> <img src="gallery/pic6.jpg"/></a>
           <a class="four" href="gallery/img7.jpg" data-lightbox="mygallery" data-title="Anna Bus Stand"> <img src="gallery/pic7.jpg"/></a>
           <a class="four" href="gallery/img8.jpg" data-lightbox="mygallery" data-title="Anna Bus Stand"> <img src="gallery/pic8.jpg"/></a>
           <a class="four" href="gallery/img9.jpg" data-lightbox="mygallery" data-title="Anna Bus Stand"> <img src="gallery/pic9.jpg"/></a>
           <a class="four" href="gallery/img10.jpg" data-lightbox="mygallery" data-title="Anna Bus Stand"> <img src="gallery/pic10.jpg"/></a>
        </div>
    </body>
</html>
<?php
include "./footer.php";
?>
