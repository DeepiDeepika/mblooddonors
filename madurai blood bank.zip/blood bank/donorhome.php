<html>
<?php
session_start();
if(isset($_SESSION['user'])) {
?>
<frameset rows="30%,*" border="0">
<frame src="donorpage.php">
<frame name="bottom">
</frameset>
<?php
}
else
echo "<hr><h3 align='center'>You are Not Authorized to view the page</h3><hr>";
?>
</html>