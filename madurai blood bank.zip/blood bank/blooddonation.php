        
           
        
       <?php
include "./header.php";
?>
<br><br>
<br>
<br>
<br>
<br>
<html>
<body>
<style>
body{
    margin:0%; padding: 0%;
    background-image: url("lab.jpg");
    background-size: cover;
    background-position: center;
    font-family: sans-serif;

}

h1 {
    font-family: 'roboto', serif;
    font-size: 60px;
    line-height: 1.125;
    margin-bottom: 10px;
    letter-spacing: -3px;
    text-align: center;
  }
  @media (min-width: 800px) {
    h1 {
      font-size: 80px;
      color: black;
      text-align: left;
      font-weight: lighter;
    }
  }



.title p {
    font-size: 25px;
    line-height: 28px;
    font-family: georgia, times, serif;
    color: whitesmoke;
    font-weight: lighter;
    
  }

  
  .well {
      background-color: rgba(74, 67, 67, 0.40);
      margin: 100px;
      border: 2px solid #ffffff;
      border-radius: 50px;
      }
  
  
  

</style>
   <section >

        <div class="title">
            <div class="animated slideInUp">
                <div class="well">
            <ul>
            <h1>Tips on donating</p></h1>
            <p>Donors have to consume good meal atleast 3hours before denoting blood.</p>
            <p>Must avoid smoking and consuming alcohol before donation and if you consumed alcohol 48 hours before donationg, you are not eligible to donate blood. </p>
            <p>The requirements before blood donation are that the donor's weight should be at least 45 kg, be at least 18 years old, and be healthy otherwise.</p>
            <p>After donating also you have to take good meal.</p>
        </ul>
        </div>
    </div>
        </div>
       </section>			
</body>
</html>