<?php
include "./header3.php";
?>
<html>
    <head>
        <title>NP</title>
        <body>
            <link rel="stylesheet" type="text/css" href="mnb.css">
        <div class="title">
            <div class="animated slideInUp">
                <div class="well">
            <ul>
            <h1>Most needed Blood</p></h1>
            <p>Commonly,All blood types are needed. However, people with O-ve blood are particularly in demand because they are the "Universal donor".</p>
            <p>People of all blood types can receive O+ve blood safely, and it is used during emergency situation when matching blood type is in short supply.</p>
            <p>It's stated that around 8% of people have O-negative blood, but O-negative blood makes up 13% of requests from hospitals..</p>
            <p>Any blood type is a rare blood type that is needed by patients, and it is also difficult to find in people.</p>
        </ul>
        </div>
    </div>
        </div>
    </body>
</head>
</html>