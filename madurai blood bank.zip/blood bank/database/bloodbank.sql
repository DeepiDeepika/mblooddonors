-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 01, 2022 at 05:01 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bloodbank`
--
CREATE DATABASE IF NOT EXISTS `bloodbank` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `bloodbank`;

-- --------------------------------------------------------

--
-- Table structure for table `acceptor`
--

CREATE TABLE IF NOT EXISTS `acceptor` (
  `name` varchar(100) DEFAULT NULL,
  `addr` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `userid` varchar(50) NOT NULL,
  `pwd` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acceptor`
--

INSERT INTO `acceptor` (`name`, `addr`, `city`, `mobile`, `userid`, `pwd`) VALUES
('Anand', '343,South street,', 'Madurai', '9584949490', 'anand', 'anand'),
('kumar', 'kumar cottage', 'madurai', '9287463434', 'kumar', 'kumar');

-- --------------------------------------------------------

--
-- Table structure for table `acceptorreq`
--

CREATE TABLE IF NOT EXISTS `acceptorreq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(100) DEFAULT NULL,
  `reqdate` date DEFAULT NULL,
  `bgroup` varchar(10) DEFAULT NULL,
  `requnit` int(11) DEFAULT NULL,
  `issunit` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `acceptorreq`
--

INSERT INTO `acceptorreq` (`id`, `userid`, `reqdate`, `bgroup`, `requnit`, `issunit`) VALUES
(1, 'anand', '2015-03-07', 'ab+', 3, 3),
(2, 'kumar', '2022-05-01', 'o+', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bloodrequest`
--

CREATE TABLE IF NOT EXISTS `bloodrequest` (
  `reqid` int(11) NOT NULL AUTO_INCREMENT,
  `hid` int(11) DEFAULT NULL,
  `hname` varchar(100) DEFAULT NULL,
  `reqdate` date DEFAULT NULL,
  `bloodgroup` varchar(10) DEFAULT NULL,
  `requnit` int(11) DEFAULT NULL,
  PRIMARY KEY (`reqid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `bloodrequest`
--

INSERT INTO `bloodrequest` (`reqid`, `hid`, `hname`, `reqdate`, `bloodgroup`, `requnit`) VALUES
(1, 1, 'Care Hospital', '2015-01-12', 'ab1+', 7),
(2, 2, 'Mothers Grace Hospital', '2015-01-12', 'o+', 0),
(3, 3, 'SriRam Hospital', '2015-01-17', 'ab2+', 1),
(4, 4, 'Anu Hospitals', '2015-03-11', 'ab+', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bloodstore`
--

CREATE TABLE IF NOT EXISTS `bloodstore` (
  `tranid` int(11) NOT NULL AUTO_INCREMENT,
  `donorid` int(11) DEFAULT NULL,
  `donorname` varchar(100) DEFAULT NULL,
  `bloodgroup` varchar(10) DEFAULT NULL,
  `doningdate` date DEFAULT NULL,
  `units` int(11) DEFAULT NULL,
  `issued` varchar(10) DEFAULT 'no',
  `issuedto` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`tranid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `bloodstore`
--

INSERT INTO `bloodstore` (`tranid`, `donorid`, `donorname`, `bloodgroup`, `doningdate`, `units`, `issued`, `issuedto`) VALUES
(1, 1, 'Anand', 'o+', '2015-01-11', 1, 'yes', NULL),
(2, 2, 'David Kumaran', 'ab+', '2015-01-12', 1, 'yes', NULL),
(3, 5, 'Vasanth', 'o+', '2015-01-12', 1, 'yes', NULL),
(4, 6, 'Iniya', 'o+', '2015-01-12', 1, 'yes', NULL),
(5, 7, 'Varun', 'ab1+', '2015-01-17', 1, 'yes', NULL),
(6, 7, 'Varun', 'ab1+', '2015-03-29', 1, 'yes', NULL),
(7, 7, 'Varun', 'ab1+', '2015-03-29', 1, 'yes', NULL),
(8, 8, 'Samuel', 'ab2+', '2015-03-29', 1, 'yes', NULL),
(9, 10, 'Santhosh', 'ab+', '2015-03-11', 1, 'yes', NULL),
(10, 7, 'Varun', 'ab1+', '2015-03-07', 1, 'no', NULL),
(11, 2, 'David Kumaran', 'ab+', '2015-03-07', 1, 'yes', NULL),
(12, 10, 'Santhosh', 'ab+', '2015-03-07', 1, 'yes', NULL),
(13, 12, 'Amarnath', 'ab+', '2015-03-07', 1, 'yes', NULL),
(14, 13, 'Baskaran', 'ab+', '2015-03-07', 1, 'no', NULL),
(15, 2, 'David Kumaran', 'ab+', '2022-05-01', 1, 'no', NULL),
(16, 14, 'ragu', 'o+', '2022-05-01', 1, 'no', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `donorissued`
--

CREATE TABLE IF NOT EXISTS `donorissued` (
  `donorid` int(11) NOT NULL,
  `donorname` varchar(100) DEFAULT NULL,
  `issueddate` date DEFAULT NULL,
  `nextissue` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donorissued`
--

INSERT INTO `donorissued` (`donorid`, `donorname`, `issueddate`, `nextissue`) VALUES
(1, 'Anand', '2011-01-11', '2011-07-10'),
(2, 'David Kumaran', '2011-01-12', '2011-07-11'),
(5, 'Vasanth', '2011-01-12', '2011-07-11'),
(6, 'Iniya', '2011-01-12', '2011-07-11'),
(7, 'Varun', '2011-01-17', '2011-07-16'),
(7, 'Varun', '2011-09-29', '2012-03-27'),
(8, 'Samuel', '2011-09-29', '2012-03-27'),
(10, 'Santhosh', '2014-03-11', '2014-09-07'),
(7, 'Varun', '2015-03-07', '2015-09-03'),
(2, 'David Kumaran', '2015-03-07', '2015-09-03'),
(10, 'Santhosh', '2015-03-07', '2015-09-03'),
(12, 'Amarnath', '2015-03-07', '2015-09-03'),
(13, 'Baskaran', '2015-03-07', '2015-09-03'),
(2, 'David Kumaran', '2022-05-01', '2022-10-28'),
(14, 'ragu', '2022-05-01', '2022-10-28');

-- --------------------------------------------------------

--
-- Table structure for table `lists`
--

CREATE TABLE IF NOT EXISTS `lists` (
  `area` varchar(50) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `ph` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lists`
--

INSERT INTO `lists` (`area`, `name`, `ph`) VALUES
('madurai', 'dhan foundation', '9855566585'),
('madurai', 'sai reserves', '9588877855'),
('madurai', 'human bonds', '9566655855'),
('chennai', 'dhan foundation', '9944455888');

-- --------------------------------------------------------

--
-- Table structure for table `newuser`
--

CREATE TABLE IF NOT EXISTS `newuser` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `marital` varchar(10) DEFAULT NULL,
  `father` varchar(50) DEFAULT NULL,
  `addr` varchar(100) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `edu` varchar(10) DEFAULT NULL,
  `college` varchar(40) DEFAULT NULL,
  `phys` varchar(10) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `drug` varchar(30) DEFAULT NULL,
  `blood` varchar(20) DEFAULT NULL,
  `ill` varchar(30) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `certificate` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `newuser`
--

INSERT INTO `newuser` (`userid`, `name`, `gender`, `age`, `marital`, `father`, `addr`, `city`, `mobile`, `edu`, `college`, `phys`, `height`, `weight`, `drug`, `blood`, `ill`, `photo`, `certificate`) VALUES
(1, 'Anand', 'male', 35, 'yes', 'Ram Kumar', '12,south st.,', 'Madurai', '9855566555', 'pg', 'TC', 'no', 185, 85, 'none,', 'o+', 'none', './pics/anand.jpg', './proofs/anand proof.jpg'),
(2, 'David Kumaran', 'male', 40, 'yes', 'James Kumaran', '121,South Street,', 'Dindigul', '9566655858', 'pg', 'PKN', 'no', 160, 89, 'none,', 'ab+', 'none', './pics/J0341328.JPG', './proofs/admin.jpg'),
(3, 'Logesh Kumar', 'male', 40, 'yes', 'Hariharan', '222,Tank Road,', 'Madurai', '9899999888', 'others', 'ARN College', 'no', 155, 70, 'none,', 'a1+', 'none', './pics/Baby7.jpg', './proofs/144041_176.gif'),
(4, 'Raghavan', 'male', 45, 'yes', 'Kumar', '222,Douglas Road', 'Chennai', '9877474744', 'ug', 'Govt. Arts College', 'no', 167, 85, 'none,', 'o+', 'none', './pics/64320.jpg', './proofs/v3.bmp'),
(5, 'Vasanth', 'male', 25, 'no', 'Gnanasambantham', '232,North Agraharam,', 'Chennai', '9588855878', 'pg', 'PSG', 'no', 155, 65, 'none,', 'o+', 'none', './pics/2.jpg', './proofs/[Fwd AMBAJOGAI_PRIDE The Last1.jpg'),
(6, 'Iniya', 'female', 26, 'no', 'Arulanandam', '232,Thambuchetty st,', 'Chennai', '9566658558', 'ug', 'Stella Marys', 'no', 160, 59, 'none,', 'o+', 'none', './pics/Pappa3.jpg', './proofs/[Fwd AMBAJOGAI_PRIDE The Last5.jpg'),
(7, 'Varun', 'male', 35, 'yes', 'Mohana Sundaram', '121,South lane', 'Trichy', '9562365855', 'pg', 'MKU', 'no', 185, 75, 'none,', 'ab1+', 'none', './pics/duke.jpg', './proofs/admin.jpg'),
(8, 'Samuel', 'male', 29, 'no', 'Gerald', '121,South STreet,', 'Chennai', '9955566585', 'ug', 'PKN', 'no', 185, 80, 'none,', 'ab2+', 'none', './pics/barimage.bmp', './proofs/images_off.bmp'),
(10, 'Santhosh', 'male', 26, 'no', 'ArunKumar', '323,south street', 'Madurai', '9988877777', 'ug', 'MKU', 'no', 195, 75, 'none,', 'ab+', 'none', './pics/Koala.jpg', './proofs/Chrysanthemum.jpg'),
(12, 'Amarnath', 'male', 39, 'yes', 'Sundaram', '343,North street,', 'Madurai', '9877788788', 'ug', 'MKU', 'no', 160, 75, 'none,', 'ab+', 'none', './pics/RMN.jpg', './proofs/emplo.jpg'),
(13, 'Baskaran', 'male', 49, 'yes', 'Rajan', '84,Main street,', 'Madurai', '8899900918', 'ug', 'TU', 'no', 17, 85, 'none,', 'ab+', 'none', './pics/ewan.jpg', './proofs/factory.gif'),
(14, 'ragu', 'male', 3, 'yes', 'kumar', 'ragu cottage', 'Madurai', '9827463433', 'p2', '-', 'no', 5, 56, 'none,', 'o+', 'six', './pics/b1.png', './proofs/b2.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
