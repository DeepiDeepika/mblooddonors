<?php
session_start();
?>
<?php
include "./header.php";
?>

   <section >
<link rel="stylesheet" a href="donorlogin.css"/>
        
        <div align='center'>

<form action="donorlogin.php" method="post">
<table>
<tr>
<th colspan="2">Donor Login
<tr>
<td align="right">Donor Id</td>
<td><input type="text" name="t1"></td>
</tr>
<tr>
<td align="right">UserName</td>
<td><input type="password" name="t2"></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="Donor Login"></td>
</tr>
<tr>
<td colspan="2" align="center">New User? &nbsp;<a href="newuser.php">Register Now</a></td>
</tr>
</table>
</form>
<?php
include("db.php");
if(isset($_POST['submit'])) {
if(!empty($_POST['t1']) && !empty($_POST['t2'])) {

	$id=$_POST['t1'];
	$un=$_POST['t2'];
	$rs=mysql_query("select * from newuser where userid=$id and name='$un'") or die(mysql_error());	

	if(mysql_num_rows($rs) >0) {
	$_SESSION['user']=$id;
	header('Location:donorpage.php');
	}
	else {
	header('Location:donorlogin.php');
	}
}
}
?>
        </div>
       </section>       
        
        
</body></html>