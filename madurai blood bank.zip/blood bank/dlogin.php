<?php
session_start();
?>
<?php
include "./headers.php";
?>

<html>
<head>
   <section >
<link rel="stylesheet" a href="dlogin.css"/>
        
        <div align='center'>
	<title>Donor Login</title>
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>
<body>
	<div class="container">
	<img src="lp.jpg"/>
		<form action="dlogin.php" method="post">
			<div class="form-input">
				<input type="text" name="t1" placeholder="Enter the Login Id"/>	
			</div>
			<div class="form-input">
				<input type="password" name="t2" placeholder="Password"/>
			</div>
			<input type="submit" name="submit" value="Donor Login" class="btn-login"><br>
                        <p class="message">Not Registered? <a href="newuser.php">Register</a></p>

		</form>
	</div>
<?php
include("db.php");
if(isset($_POST['submit'])) {
if(!empty($_POST['t1']) && !empty($_POST['t2'])) {

	$id=$_POST['t1'];
	$un=$_POST['t2'];
	$rs=mysql_query("select * from newuser where userid=$id and name='$un'") or die(mysql_error());	

	if(mysql_num_rows($rs) >0) {
	$_SESSION['user']=$id;
	header('Location:donorpage.php');
	}
	else {
	header('Location:dlogin.php');
	}
}
}
?>
        </div>
       </section>       
        
</body>
</html>