<?php
include "./header.php";
?>
   <section >
         <div class="about-us">
                     <h1>About Us</h1>
         <div class="wrapper">
                        <div class="content">
                     <h3>Founder of Madurai Blood Donors </h3>
           <div class="image-section">
                      <img src="img.jpg"  style="float: right">
               </div>
                     <p>S.Kamaludeen Madani is the founder of Madurai Blood Donors. He started Madurai Blood Donors in 1986.
He started this Non-profit organization to help people in need of blood.Madurai Blood Donors have organized blood camps conducted in 
various places to meet the demands of blood for needed people. They have 25 years of organizing Blood Camps, Blood Donation, 
Financial Medical Aid all over Tamil Nadu and also provide education help.The Head office of the community is located in Madurai. 
They also have Sub Branches. </p>     
                   </div>
                  
           </div>

       </div>
    </section>
</header>
</body>
</html>
<?php
include "./footer.php";
?>


