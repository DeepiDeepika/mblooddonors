<?php
session_start();
if(!isset($_SESSION['acceptor'])) {
header("Location:photogallery.php");
}
include("db.php");
?>
<html >
<head>
       <meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="stylesheet" type="text/css" href="abt.css">  
       <script src="https://kit.fontawesome.com/64d58efce2.js" ></script>
      <title> Blood Request</title>

</head>
<body >
      <header>
      <div class="main">
            <div class="logo">
            <img src="logo.png">
            </div>

            <div class="nav-btn">
              <div class="nav-links">
                  <ul>
                      <li class="nav-link" style="--i: .6s">
                          <a href="homepage.php">Home</a>
                      </li>
                      <li class="nav-link" style="--i: .6s">
                          <a href="logout.php">Logout</a>
                      </li>
 </ul>
                      
                   
                    </ul>
                </div>
            </div>


<br>
<br>
<br>
<br>

          <section >
<div align='center'>
             
<?php
if(!isset($_POST['submit'])) {
?>
<div class="container">
<form name="f" action="" method="post">
<table style="margin:auto;">
<tr>
<th>User Id
<td><input type="text" name="userid" value="<?php echo $_SESSION[acceptor]?>" readonly><br>
<tr>
<th class="alnr">Required BloodGroup</td>
<td>
<select name="bgroup" required>
<option value="">Select</option>
<option value="o+">O+</option>
<option value="o-">O-</option>
<option value="a1+">A+</option>
<option value="a1-">A-</option>
<option value="b+">B+</option>
<option value="b-">B-</option>
<option value="ab+">AB+</option>
<option value="ab-">AB-</option>
</select>
</td>
</tr><br>
<tr>
<th>Units Needed
<td><input type="text" name="units" pattern="\d+" required></td>
<br>
<br>
<tr>
<th colspan="2"><input type="submit" name="submit" value="Send Request" class="btn-login">
</table>
</form>
</div>
<?php
} else {
	$userid = $_POST['userid'];
	$bgroup = $_POST['bgroup'];
	$units = $_POST['units'];
	$reqdate = date('Y-m-d',time());

	mysql_query("insert into acceptorreq (userid,reqdate,bgroup,requnit) values ('$userid','$reqdate','$bgroup',$units)") or die(mysql_error());
	echo "<br><center><h3>Request Send</h3><br><a href='acceptorhome.php'>Back</a></center>";
}
?>
</section>
</body>
<style>
.container{
	width: 400px;
	height: 250px;
	text-align: center;
	margin: 0 auto;
	background-color: #F08080;
	margin-top: 100px;
        border-radius: 20px;
}

.container img{
	width: 125px;
	height: 125px;
	margin-top: -60px;
        box-sizing: border-box;
        border-radius: 50%;
        }

.container p{
    margin: 0;
    padding: 0;
    font-weight: bold;
    
}

.container p a{
    margin: 0;
    padding: 0;
    font-weight: bold;
    font-color: white;
}
.btn-login{
	padding: 10px 20px;
	border: none;
	background-color: black;
	color: white;
        border-radius: 20px;
}

</style>
</html>