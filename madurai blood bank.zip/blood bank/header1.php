<html >
<head>
       <meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="stylesheet" type="text/css" href="abt1.css">  
       <script src="https://kit.fontawesome.com/64d58efce2.js" ></script>
      <title> Madurai Blood Donors </title>

</head>
<body>
      <header>
      <div class="main">
            <div class="logo">
            <img src="logo.png">
            </div>
            <div class="nav-btn">
              <div class="nav-links">
                  <ul>
                      <li class="nav-link" style="--i: .6s">
                          <a href="homepage.php">Home</a>
                      </li>
                      <li class="nav-link" style="--i: .6s">
                          <a href="about.php">About</a>
                      </li>
                       
 

          <li class="nav-link" style="--i: .6s">
              <a href="Gallery.php">Gallery</a>
          </li>
          <li class="nav-link" style="--i: .85s">
              <a href="#">Donation Process<i class="fas fa-caret-down"></i></a>
              <div class="dropdown">
                  <ul>
                      <li class="dropdown-link"  >
                          <a href="dlogin.php">Donor Login</a>
                      </li>
                      <li class="dropdown-link">
                          <a href="TOD.php">Tips on Donating</a>
                      </li>
                     
                  </ul>
              </div>
            </li>
           <li class="nav-link" style="--i: .6s">
                          <a href="photogallery.php">Blood Request</a>
                      </li>
          <li class="nav-link" style="--i: 1.35s">
              <a href="c.php">Contact & Location</a>
          </li>
          <li class="nav-link" style="--i: .85s">
            <a href="#">Learn More<i class="fas fa-caret-down"></i></a>
            <div class="dropdown">
                <ul>
                    <li class="dropdown-link">
                        <a href="mnb.php">Most Needed Blood</a>
                    </li>
                    <li class="dropdown-link">
                        <a href="nps.php">Needed People</a>
                    </li>
                </ul>
            </div>
          </li>
          <li class="nav-link" style="--i: 1.35s">
            <a href="adminlogin.php">Admin login</a>
        </li>
          
                    </ul>
                </div>
            </div>
